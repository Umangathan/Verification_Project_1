﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Modest.Teaching;
using CI = System.Globalization.CultureInfo;

namespace TransitionSystemChecker
{
	class Checker: ITransitionSystemAnalyzer
	{
		public Checker() // called from Program.cs
		{
			// Perform initialisation work that does not depend on command-line arguments and that cannot fail here if necessary.
		}

		public bool ParseCommandLine(string[] args) // called from Program.cs
		{
			// Parse additional command-line parameters here if necessary.
			// args[0] is used for the model input file name in Program.cs and should be ignored.
			// If the given parameters are not valid, report an error on Console.Error and return false; otherwise, return true.
			return true;
		}

		public void AnalyzeTransitionSystem<T>(TransitionSystem<T> transitionSystem, ModelProperty[] properties) // called from Program.cs
			where T: struct, Modest.Exploration.IState<T>
		{
			// Implement your transition system analysis procedures here
			// For illustration, let's count the immediate successors of the initial state:
			var successors = new HashSet<T>(); // the state types implement proper .GetHashCode and .Equals methods based on structural equality
			T initialState, successorState;
			transitionSystem.GetInitialState(out initialState);
			foreach(var transition in transitionSystem.GetTransitions(ref initialState))
			{
				transitionSystem.GetTargetState(ref initialState, transition, out successorState);
				successors.Add(successorState);
				// We could evaluate properties using transitionSystem.HasAtomicProposition(ref successorState, ...) here;
				// also see the class diagram for properties (file Properties-Classes.png).
			}
			Console.WriteLine("The initial state has " + successors.Count.ToString(CI.InvariantCulture) + " distinct immediate successor state" + (successors.Count == 1 ? string.Empty : "s") + ".");
		}
	}
}
